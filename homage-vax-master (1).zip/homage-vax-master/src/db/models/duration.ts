export class Duration {
  start: string;
  end: string;
}
